﻿using System;
using System.Collections.Generic;

namespace StarWars.API.Models;

public partial class Helyszin
{
    public int Id { get; set; }

    public string Nev { get; set; } = null!;

    public int KezdoX { get; set; }

    public int KezdoY { get; set; }

    public int VegX { get; set; }

    public int VegY { get; set; }
}
