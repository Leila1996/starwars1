﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace StarWars.API.Models;

public partial class StarwarsContext : DbContext
{
    public StarwarsContext()
    {
    }

    public StarwarsContext(DbContextOptions<StarwarsContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Helyszin> Helyszins { get; set; }

    public virtual DbSet<Karakter> Karakters { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=localhost;user=root;database=starwars", Microsoft.EntityFrameworkCore.ServerVersion.Parse("10.4.32-mariadb"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_general_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Helyszin>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("helyszin");

            entity.HasIndex(e => new { e.KezdoX, e.KezdoY, e.VegX, e.VegY }, "koordinata").IsUnique();

            entity.HasIndex(e => e.Nev, "nev").IsUnique();

            entity.Property(e => e.Id)
                .HasColumnType("int(11)")
                .HasColumnName("id");
            entity.Property(e => e.KezdoX)
                .HasColumnType("int(11)")
                .HasColumnName("kezdo_X");
            entity.Property(e => e.KezdoY)
                .HasColumnType("int(11)")
                .HasColumnName("kezdo_Y");
            entity.Property(e => e.Nev)
                .HasMaxLength(50)
                .HasColumnName("nev");
            entity.Property(e => e.VegX)
                .HasColumnType("int(11)")
                .HasColumnName("veg_X");
            entity.Property(e => e.VegY)
                .HasColumnType("int(11)")
                .HasColumnName("veg_Y");
        });

        modelBuilder.Entity<Karakter>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("karakter");

            entity.HasIndex(e => e.Nev, "nev").IsUnique();

            entity.Property(e => e.Id)
                .HasColumnType("int(11)")
                .HasColumnName("id");
            entity.Property(e => e.KoordinataX)
                .HasColumnType("int(11)")
                .HasColumnName("koordinata_X");
            entity.Property(e => e.KoordinataY)
                .HasColumnType("int(11)")
                .HasColumnName("koordinata_Y");
            entity.Property(e => e.Nev)
                .HasMaxLength(50)
                .HasColumnName("nev");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
