﻿using System;
using System.Collections.Generic;

namespace StarWars.API.Models;

public partial class Karakter
{
    public int Id { get; set; }

    public string Nev { get; set; } = null!;

    public int KoordinataX { get; set; }

    public int KoordinataY { get; set; }
}
