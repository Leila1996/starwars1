﻿using System.ComponentModel.DataAnnotations;

namespace StarWars.API.Models
{
    public class Koordinata
    {
        [Range(0, 2601)]
        public int X { get; set; }

        [Range(0, 2172)]
        public int Y { get; set; }

        // Konstruktor, amely beállítja az értékeket
        public Koordinata(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}
