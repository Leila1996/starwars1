﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StarWars.API.Models;

namespace StarWars.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HelyszinController : ControllerBase
    {
        private readonly StarwarsContext _context;

        public HelyszinController(StarwarsContext context)
        {
            _context = context;
        }
        // POST: api/Helyszin
        [HttpPost]
        public async Task<ActionResult<string>> Helyszin(Koordinata koordinata)
        {
        // Megkeressük, hogy van-e olyan helyszín, amely tartalmazza a koordinátát
            var helyszin = await _context.Helyszins
                .Where(h => h.KezdoX <= koordinata.X && h.VegX >= koordinata.X &&
                            h.KezdoY <= koordinata.Y && h.VegY >= koordinata.Y)
                .FirstOrDefaultAsync();

            if (helyszin == null)
            {
                return "A térképen nem szerepel ez a helység.";
            }

            return $"A helység neve: {helyszin.Nev}";
        }
    }
}
