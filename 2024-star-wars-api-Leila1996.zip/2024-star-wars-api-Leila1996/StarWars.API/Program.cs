using Microsoft.EntityFrameworkCore;
using StarWars.API;
using StarWars.API.Models;

namespace StarWars.API
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);



            // Add services to the container.
            builder.Services.AddDbContext<StarwarsContext>(options =>
            {
                options.UseMySql(builder.Configuration.GetConnectionString("StarwarsDB"), ServerVersion.Parse("10.4.32-mariadb"));
            // SQL param�terek mutat�sa a log-ban
                options.EnableSensitiveDataLogging();
            });


            builder.Services.AddControllers();

            var app = builder.Build();

            // Configure the HTTP request pipeline.

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}