[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/shJsWwd6)
# Menekülés a Halálcsillagról

Luke Skywalker és csapata és az Ezeréves Sólyom legénysége, kiszeretné szabadítani Leila hercegnőt a Halálcsillagról. Droidjai, R2-D2 és C3-PO sikeresen bejutott a vezérlőközpontba, ahol navigálni tudják a csapat többi tagját.
 A mellékelt segédeszközökkel segítsen meghatározni a csapattagok pontos helyét, és kijutni a Halálcsillagról.

![Halálcsillag](Forrás/terkep.jpg)

1. Töltse fel a MySQL adatbázist az Forrás mappába mellékelt *halalcsillag_export.sql* fájl alapján.

2. A kiinduló Web API projektbe telepítse fel a szükséges NuGet csomagokat az **Entity Framework** használatához!

3. A *pm_command.txt* fájlban lévő utasítás még nem teljes. Az idézőjeles részbe be kell illeszteni egy connectionStringet. Az alábbi adatokat pontosvesszővel kell elválasztani és beilleszteni:
    - **server** = localhost
    - **user** **id** = root
    - **database** = A feltöltött adatbázis neve

A **Package Manager Console** felületén adja ki a kiegészített parancsot. Ezzel a paranccsal sikerül lemodellezni az adatbázis táblákat és elkészíti a context osztályt is.

4. A *Program.cs* fájlban adja hozzá az *AddDbContext* függőséget.

5. Hozzon létre a *Models* mappában egy *Koordinata* osztályt. Az osztálynak az alábbi értékei legyenek:
    - Publikus egész szám változók: X és Y
    - Mindkét változó felett legyen egy szabály attribútum, X-nél: [Range(0,2601)], Y-nál: 0 és 2172 a szélső érték. A Range attribútumhoz szükség lesz a *System.ComponentModel.DataAnnotations* könyvtárra.
    - Az osztálynak legyen egy konstruktora, amely beállítja az értékeket a paraméterek alapján.

6. A Controllers mappában hozzon létre egy üres API Controller osztályt *HelyszinController* néven!
    - Az osztálynak legyen egy privát változója a context osztályról.
    - Legyen egy paraméteres konstruktora, ami értéket ad a context változónak.
7. Hozzon létre egy *string* típusú (publikus) végpontot *Helyszin* néven, ami paraméterként egy *Koordinata típusú* változót vár. A végpontot csak HTTP POST metódussal lehessen elérni. Alapértelmezetten üzenetként adja vissza, hogy „A térképen nem szerepel ez a helység.&quot;.

8. Készítsen egy másik *string* típusú végpontot szintén *Helyszin* néven, ami paraméterként egy *karakterNev (string)* változót vár. A végpontot HTTP GET metódussal lehessen elérni. Alapértelmezetten üzenetként adja vissza, hogy „A karakter nincs a Halálcsillagon.&quot;.

9. Készítsen egy kereső metódust *Kereses* néven. A helyszíneknek vannak kezdő és egy vég koordinátái. A kezdőpont a bal felső sarkot, a vég a jobb alsó sarkot jelöli a térképen. A paraméterként kapott koordináta alapján és az adatbázisban tárolt helyiségek kezdő és végkoordinátái segítségével, határozza meg, hogy melyik helyiségben van az adott pont vagy karakter.

10. A web API végpontjait tesztelje **StarWars.API.http** fájl segítéségével.

**Bónusz feladat:**

R2-D2-nak le kell kérdeznie az ajtókhoz tartozó kódot, amivel fel tudja törni a helyszínekhez tartozó zárakat. A hozzá tartozó kulcsok BCrypt titkosításban vannak, a helyszín kezdő koordinátáit tartalmazzák összefűzve.

11. Telepítse fel a **BCrypt.Net-Next** NuGet csomagot a projekthez.

12. Készítsen egy másik Controller osztályt *KulcsController* néven, hasonlóan a *HelyszinController* alapján.

13. Hozzon létre egy *string* típusú végpontot *KapuKod* néven, ami paraméterként egy *helyszinNev* változót vár. A végpontot csak HTTP GET metódussal lehessen elérni. Alapértelmezett üzenetként adja vissza, hogy „A helyiség nincs a Halálcsillagon.&quot;.

Fejezze be a végpontot úgy, hogy a kapott helységnév alapján adja vissza a helyszín X és Y kezdőkoordinátáit összefűzve, **BCrpyt** titkosításban.
